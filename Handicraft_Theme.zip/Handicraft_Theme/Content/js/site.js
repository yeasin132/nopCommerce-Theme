(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {
        var stickyAdd = document.querySelector(".hc-sticky-add");
        if (stickyAdd) {
            document.body.classList.add("hc-has-sticky-add");
        }

    });
})();
