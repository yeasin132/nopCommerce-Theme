﻿/* =====================================================
   SITE AUTH + HOME COMBINED JS
   - Login
   - Register
   - Home
   nopCommerce SAFE
===================================================== */

document.addEventListener("DOMContentLoaded", function () {

  /* =====================================================
     1. PASSWORD TOGGLE (LOGIN + REGISTER) – FIXED
  ===================================================== */

  document.querySelectorAll(".password-eye").forEach(function (eye) {
    eye.addEventListener("click", function () {

      // Find closest password input inside same wrapper
      const wrapper = this.closest(".login-password, .inputs");
      if (!wrapper) return;

      const input = wrapper.querySelector("input[type='password'], input[type='text']");
      if (!input) return;

      const isPassword = input.type === "password";

      input.type = isPassword ? "text" : "password";

      // Toggle icon safely
      this.textContent = isPassword ? "🙈" : "👁";
      this.classList.toggle("password-eye-open", isPassword);
    });
  });

  /* =====================================================
     2. AUTO-FOCUS FIRST INPUT (LOGIN / REGISTER)
  ===================================================== */

  const firstInput = document.querySelector(
    ".login-page input:not([type=hidden]), .registration-page input:not([type=hidden])"
  );

  if (firstInput) {
    firstInput.focus();
  }

  /* =====================================================
     3. DISABLE DOUBLE SUBMIT (REGISTER ONLY)
  ===================================================== */

  const registerForm = document.querySelector(".registration-page form");

  if (registerForm) {
    registerForm.addEventListener("submit", function () {
      const btn = registerForm.querySelector("#register-button");
      if (btn) {
        btn.disabled = true;
        btn.classList.add("is-loading");
      }
    });
  }

  /* =====================================================
     4. HOME PAGE CARD HOVER FIX (MOBILE SAFETY)
  ===================================================== */

  if (document.body.classList.contains("home-page")) {
    document.querySelectorAll(".item-box").forEach(function (card) {
      card.addEventListener("touchstart", function () {
        this.classList.add("hover");
      });
    });
  }

  /* =====================================================
     5. SMOOTH SCROLL FOR ANCHORS (OPTIONAL)
  ===================================================== */

  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener("click", function (e) {
      const target = document.querySelector(this.getAttribute("href"));
      if (!target) return;

      e.preventDefault();
      target.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });
  });

  /* =====================================================
     6. HEADER MENU DROPDOWNS (CLICK SUPPORT)
  ===================================================== */

  const headerMenu = document.querySelector(".header-menu .menu-container");

  if (headerMenu) {
    const closeOpenMenus = function () {
      headerMenu
        .querySelectorAll(".menu__item.menu-dropdown--active")
        .forEach(function (item) {
          item.classList.remove("menu-dropdown--active");
        });
    };

    headerMenu.addEventListener(
      "click",
      function (event) {
        const toggle = event.target.closest(".menu__item-toggle");
        if (!toggle || !headerMenu.contains(toggle)) return;

        const menuItem = toggle.closest(".menu__item.menu-dropdown");
        if (!menuItem) return;

        const link = toggle.querySelector(".menu__link");
        const href = link ? link.getAttribute("href") : null;
        const hasRealHref =
          href &&
          href !== "#" &&
          href !== "javascript:void(0)" &&
          href !== "javascript:void(0);";
        const isOpen = menuItem.classList.contains("menu-dropdown--active");

        if (!isOpen) {
          closeOpenMenus();
          event.preventDefault();
        } else if (!hasRealHref) {
          event.preventDefault();
        }
      },
      true
    );

    document.addEventListener("click", function (event) {
      if (!headerMenu.contains(event.target)) {
        closeOpenMenus();
      }
    });
  }

});
